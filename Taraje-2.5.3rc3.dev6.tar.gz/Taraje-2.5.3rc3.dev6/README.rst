.. raw:: html

    <h1 align="center">BL#378-Taraje</h1>

    <h3 align="center">rame-rame</h3>

    <p align="center">
        <a href="https://t.me/ampasmanusa">
            <code>bancetzLaut_</code>
        </a>
        |
        <a href="https://t.me/bancetzLaut">
            <code>ampasmanusa_</code>
        </a>
        <br>
        <a href="https://t.me/BL378Taraje">
            <code>#Tarajé__</code>
        </a>
    </p>